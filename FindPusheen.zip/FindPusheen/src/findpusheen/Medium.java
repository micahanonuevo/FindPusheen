
package findpusheen;

import javax.swing.JOptionPane;


 // @author Micah Lara

public class Medium extends javax.swing.JFrame {
     
    static int mouseclick = 0;
    static int  epusheen = 5;
    static int milliseconds = 00;
    static int seconds = 00;
    static int minutes = 00;
    static boolean state = true;
    
    
    public Medium() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        mp1 = new javax.swing.JLabel();
        mp2 = new javax.swing.JLabel();
        mp3 = new javax.swing.JLabel();
        mp4 = new javax.swing.JLabel();
        mp5 = new javax.swing.JLabel();
        mbg = new javax.swing.JLabel();
        mback = new javax.swing.JLabel();
        mtitle_lbl = new javax.swing.JLabel();
        mcounter_lbl = new javax.swing.JLabel();
        mcounter = new javax.swing.JLabel();
        mtime_lbl = new javax.swing.JLabel();
        mtime = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(253, 237, 237));
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(253, 237, 237));

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mp1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Medium/mpusheen1.png"))); // NOI18N
        mp1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mp1MouseClicked(evt);
            }
        });
        jPanel2.add(mp1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, -1, -1));

        mp2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Medium/mpusheen2.png"))); // NOI18N
        mp2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mp2MouseClicked(evt);
            }
        });
        jPanel2.add(mp2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, -1, -1));

        mp3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Medium/mpusheen3.png"))); // NOI18N
        mp3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mp3MouseClicked(evt);
            }
        });
        jPanel2.add(mp3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, -1, -1));

        mp4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Medium/mpusheen4.png"))); // NOI18N
        mp4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mp4MouseClicked(evt);
            }
        });
        jPanel2.add(mp4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, -1, -1));

        mp5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Medium/mpusheen5.png"))); // NOI18N
        mp5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mp5MouseClicked(evt);
            }
        });
        jPanel2.add(mp5, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 0, -1, -1));

        mbg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Medium/mediumlvl.png"))); // NOI18N
        mbg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mbgMouseClicked(evt);
            }
        });
        jPanel2.add(mbg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        mback.setFont(new java.awt.Font("Lucida Calligraphy", 1, 48)); // NOI18N
        mback.setText("<");
        mback.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mbackMouseClicked(evt);
            }
        });

        mtitle_lbl.setFont(new java.awt.Font("Lucida Calligraphy", 3, 48)); // NOI18N
        mtitle_lbl.setText("Medium");

        mcounter_lbl.setFont(new java.awt.Font("Lucida Calligraphy", 3, 24)); // NOI18N
        mcounter_lbl.setText("Pusheen Left:");

        mcounter.setFont(new java.awt.Font("Lucida Calligraphy", 3, 48)); // NOI18N
        mcounter.setText("5");

        mtime_lbl.setFont(new java.awt.Font("Lucida Calligraphy", 3, 24)); // NOI18N
        mtime_lbl.setText("Time:");

        mtime.setFont(new java.awt.Font("Lucida Calligraphy", 3, 48)); // NOI18N
        mtime.setText("00:00");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(mcounter, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(117, 117, 117))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(mcounter_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(mtime_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(106, 106, 106))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(mtime, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(68, 68, 68))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mback, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(246, 246, 246)
                .addComponent(mtitle_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 291, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(mback)
                        .addGap(11, 11, 11))
                    .addComponent(mtitle_lbl, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(52, 52, 52)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(mcounter_lbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(mcounter)
                        .addGap(41, 41, 41)
                        .addComponent(mtime_lbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(mtime))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(81, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

     void timerstart(){
        state = true;
        
        Thread t = new Thread(){
            @Override
            public void run(){                
                
                for(;;){
                    if(state == true){
                        try {
                            sleep(1);
                           
                            if(milliseconds>1000){
                                milliseconds = 00;
                                seconds++;
                            }
                            if(seconds>60){
                                seconds = 00;
                                minutes++;
                            }
                            
                            milliseconds++;
                            
                            
                            
                            if(seconds<10&&minutes<10){
                                mtime.setText("0"+minutes+":0"+seconds);
                            }else if(seconds<10){
                                mtime.setText(minutes+":0"+seconds);
                            }else if(minutes<10){
                                mtime.setText("0"+minutes+":"+seconds);
                            }else{
                                mtime.setText(minutes+":"+seconds);
                            }
                            
                        } catch (Exception e) {
                            
                        }
                    }
                    else{
                        break;
                    }
                }
            }
        };
        
        t.start();
        
    }
    
    void timerstop(){
        state = false;
    }
    
    void counter(){
        mcounter.setText(String.valueOf(epusheen));
        if(mouseclick ==1){
           timerstart();
       }
            
        if(epusheen == 0){
            timerstop();
            
            JOptionPane.showConfirmDialog(null,
                "Time: "+mtime.getText(),
                "Congratulations you find all the pusheen!",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE);
            
            Choices ch = new Choices();
            this.hide();
            ch.show();
        }
    }
      
    
    private void mbackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mbackMouseClicked
        Choices ch = new Choices();
        this.hide();
        ch.show();
    }//GEN-LAST:event_mbackMouseClicked

    private void mp2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mp2MouseClicked
        mp2.setVisible(false);
        mouseclick++;
        epusheen--;
        counter();
    }//GEN-LAST:event_mp2MouseClicked

    private void mp3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mp3MouseClicked
        mp3.setVisible(false);
        mouseclick++;
        epusheen--;
        counter();
    }//GEN-LAST:event_mp3MouseClicked

    private void mp1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mp1MouseClicked
        mp1.setVisible(false);
        mouseclick++;
        epusheen--;
        counter();
    }//GEN-LAST:event_mp1MouseClicked

    private void mp5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mp5MouseClicked
        mp5.setVisible(false);
        mouseclick++;
        epusheen--;
        counter();
    }//GEN-LAST:event_mp5MouseClicked

    private void mp4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mp4MouseClicked
        mp4.setVisible(false);
        mouseclick++;
        epusheen--;
        counter();
    }//GEN-LAST:event_mp4MouseClicked

    private void mbgMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mbgMouseClicked
       mouseclick++;
       counter();
    }//GEN-LAST:event_mbgMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Medium.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Medium.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Medium.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Medium.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Medium().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel mback;
    private javax.swing.JLabel mbg;
    private javax.swing.JLabel mcounter;
    private javax.swing.JLabel mcounter_lbl;
    private javax.swing.JLabel mp1;
    private javax.swing.JLabel mp2;
    private javax.swing.JLabel mp3;
    private javax.swing.JLabel mp4;
    private javax.swing.JLabel mp5;
    private javax.swing.JLabel mtime;
    private javax.swing.JLabel mtime_lbl;
    private javax.swing.JLabel mtitle_lbl;
    // End of variables declaration//GEN-END:variables
}
