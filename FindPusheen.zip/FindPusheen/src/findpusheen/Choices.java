
package findpusheen;

/**
 *
 * @author Micah Lara
 */
public class Choices extends javax.swing.JFrame {

    
    public Choices() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cpbg = new javax.swing.JPanel();
        clbl = new javax.swing.JLabel();
        cpebg = new javax.swing.JPanel();
        eprev = new javax.swing.JLabel();
        cpmbg = new javax.swing.JPanel();
        mprev = new javax.swing.JLabel();
        cphbg = new javax.swing.JPanel();
        hprev = new javax.swing.JLabel();
        easy_lbl = new javax.swing.JLabel();
        medium_lbl = new javax.swing.JLabel();
        hard_lbl = new javax.swing.JLabel();
        cback = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        cpbg.setBackground(new java.awt.Color(253, 237, 237));

        clbl.setFont(new java.awt.Font("Lucida Calligraphy", 3, 36)); // NOI18N
        clbl.setText("Choose Difficulty:");

        cpebg.setBackground(new java.awt.Color(255, 255, 204));

        eprev.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Easy/eprev.png"))); // NOI18N

        javax.swing.GroupLayout cpebgLayout = new javax.swing.GroupLayout(cpebg);
        cpebg.setLayout(cpebgLayout);
        cpebgLayout.setHorizontalGroup(
            cpebgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cpebgLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(eprev, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        cpebgLayout.setVerticalGroup(
            cpebgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cpebgLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(eprev)
                .addContainerGap())
        );

        cpmbg.setBackground(new java.awt.Color(204, 255, 204));

        mprev.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Medium/mprev.png"))); // NOI18N

        javax.swing.GroupLayout cpmbgLayout = new javax.swing.GroupLayout(cpmbg);
        cpmbg.setLayout(cpmbgLayout);
        cpmbgLayout.setHorizontalGroup(
            cpmbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cpmbgLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mprev, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        cpmbgLayout.setVerticalGroup(
            cpmbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, cpmbgLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(mprev, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        cphbg.setBackground(new java.awt.Color(204, 153, 255));

        hprev.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Hard/hprev.png"))); // NOI18N

        javax.swing.GroupLayout cphbgLayout = new javax.swing.GroupLayout(cphbg);
        cphbg.setLayout(cphbgLayout);
        cphbgLayout.setHorizontalGroup(
            cphbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cphbgLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(hprev, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        cphbgLayout.setVerticalGroup(
            cphbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cphbgLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(hprev, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        easy_lbl.setFont(new java.awt.Font("Lucida Calligraphy", 3, 24)); // NOI18N
        easy_lbl.setText("Easy");
        easy_lbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                easy_lblMouseClicked(evt);
            }
        });

        medium_lbl.setFont(new java.awt.Font("Lucida Calligraphy", 3, 24)); // NOI18N
        medium_lbl.setText("Medium");
        medium_lbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                medium_lblMouseClicked(evt);
            }
        });

        hard_lbl.setFont(new java.awt.Font("Lucida Calligraphy", 3, 24)); // NOI18N
        hard_lbl.setText("Hard");
        hard_lbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hard_lblMouseClicked(evt);
            }
        });

        cback.setFont(new java.awt.Font("Lucida Calligraphy", 1, 48)); // NOI18N
        cback.setText("<");
        cback.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cbackMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout cpbgLayout = new javax.swing.GroupLayout(cpbg);
        cpbg.setLayout(cpbgLayout);
        cpbgLayout.setHorizontalGroup(
            cpbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cpbgLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cback, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 173, Short.MAX_VALUE)
                .addComponent(clbl, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(211, 211, 211))
            .addGroup(cpbgLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(cpebg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cpmbg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(cphbg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(cpbgLayout.createSequentialGroup()
                .addGap(110, 110, 110)
                .addComponent(easy_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(184, 184, 184)
                .addComponent(medium_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(hard_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(130, 130, 130))
        );
        cpbgLayout.setVerticalGroup(
            cpbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cpbgLayout.createSequentialGroup()
                .addGroup(cpbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cpbgLayout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(clbl, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(cpbgLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cback)))
                .addGap(58, 58, 58)
                .addGroup(cpbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cpebg, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(cpbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(cphbg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cpmbg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(49, 49, 49)
                .addGroup(cpbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(medium_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(easy_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(hard_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cpbg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cpbg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void easy_lblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_easy_lblMouseClicked
        Easy e = new Easy();
        this.hide();
        e.show();
    }//GEN-LAST:event_easy_lblMouseClicked

    private void medium_lblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_medium_lblMouseClicked
        Medium m = new Medium();
        this.hide();
        m.show();
    }//GEN-LAST:event_medium_lblMouseClicked

    private void cbackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbackMouseClicked
       MainMenu mm = new MainMenu();
       this.hide();
       mm.show();
    }//GEN-LAST:event_cbackMouseClicked

    private void hard_lblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hard_lblMouseClicked
        Hard h = new Hard();
        this.hide();
        h.show();
    }//GEN-LAST:event_hard_lblMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Choices.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Choices.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Choices.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Choices.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Choices().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel cback;
    private javax.swing.JLabel clbl;
    private javax.swing.JPanel cpbg;
    private javax.swing.JPanel cpebg;
    private javax.swing.JPanel cphbg;
    private javax.swing.JPanel cpmbg;
    private javax.swing.JLabel easy_lbl;
    private javax.swing.JLabel eprev;
    private javax.swing.JLabel hard_lbl;
    private javax.swing.JLabel hprev;
    private javax.swing.JLabel medium_lbl;
    private javax.swing.JLabel mprev;
    // End of variables declaration//GEN-END:variables
}
