
package findpusheen;

 //@author Micah Lara

public class MainMenu extends javax.swing.JFrame {

    
    public MainMenu() {
        initComponents();
        
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        title_lbl = new javax.swing.JLabel();
        play_btn = new javax.swing.JLabel();
        exit_btn = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(253, 237, 237));
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(253, 237, 237));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        title_lbl.setFont(new java.awt.Font("Lucida Calligraphy", 3, 60)); // NOI18N
        title_lbl.setForeground(new java.awt.Color(102, 51, 0));
        title_lbl.setText("Find Pusheen");
        jPanel1.add(title_lbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, 520, 94));

        play_btn.setFont(new java.awt.Font("Lucida Calligraphy", 3, 36)); // NOI18N
        play_btn.setForeground(new java.awt.Color(102, 51, 0));
        play_btn.setText("Play");
        play_btn.setToolTipText("Click to play the game");
        play_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                play_btnMouseClicked(evt);
            }
        });
        jPanel1.add(play_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 140, 120, 60));

        exit_btn.setFont(new java.awt.Font("Lucida Calligraphy", 3, 36)); // NOI18N
        exit_btn.setForeground(new java.awt.Color(102, 51, 0));
        exit_btn.setText("Exit");
        exit_btn.setToolTipText("Click to close the game");
        exit_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exit_btnMouseClicked(evt);
            }
        });
        jPanel1.add(exit_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 200, 120, 60));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Banner.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 480));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 854, 480));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exit_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exit_btnMouseClicked
      this.dispose();
    }//GEN-LAST:event_exit_btnMouseClicked

    private void play_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_play_btnMouseClicked
       Choices ch = new Choices();
       this.hide();
       ch.show();
    }//GEN-LAST:event_play_btnMouseClicked

    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel exit_btn;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel play_btn;
    private javax.swing.JLabel title_lbl;
    // End of variables declaration//GEN-END:variables
}
