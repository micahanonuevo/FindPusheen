
package findpusheen;

import javax.swing.JOptionPane;


 // @author Micah Lara

public class Hard extends javax.swing.JFrame {

    static int mouseclick = 0;
    static int  epusheen = 8;
    static int milliseconds = 00;
    static int seconds = 00;
    static int minutes = 00;
    static boolean state = true;
    
    public Hard() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        hback = new javax.swing.JLabel();
        htitle_lbl = new javax.swing.JLabel();
        hcounter_lbl = new javax.swing.JLabel();
        hcounter = new javax.swing.JLabel();
        htime_lbl = new javax.swing.JLabel();
        htime = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        hp1 = new javax.swing.JLabel();
        hp2 = new javax.swing.JLabel();
        hp3 = new javax.swing.JLabel();
        hp4 = new javax.swing.JLabel();
        hp5 = new javax.swing.JLabel();
        hp6 = new javax.swing.JLabel();
        hp7 = new javax.swing.JLabel();
        hp8 = new javax.swing.JLabel();
        hbg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(253, 237, 237));

        hback.setFont(new java.awt.Font("Lucida Calligraphy", 1, 48)); // NOI18N
        hback.setText("<");
        hback.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hbackMouseClicked(evt);
            }
        });

        htitle_lbl.setFont(new java.awt.Font("Lucida Calligraphy", 3, 48)); // NOI18N
        htitle_lbl.setText("Hard");

        hcounter_lbl.setFont(new java.awt.Font("Lucida Calligraphy", 3, 24)); // NOI18N
        hcounter_lbl.setText("Pusheen Left:");

        hcounter.setFont(new java.awt.Font("Lucida Calligraphy", 3, 48)); // NOI18N
        hcounter.setText("8");

        htime_lbl.setFont(new java.awt.Font("Lucida Calligraphy", 3, 24)); // NOI18N
        htime_lbl.setText("Time:");

        htime.setFont(new java.awt.Font("Lucida Calligraphy", 3, 48)); // NOI18N
        htime.setText("00:00");

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setPreferredSize(new java.awt.Dimension(500, 270));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        hp1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Hard/hpusheen1.png"))); // NOI18N
        hp1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hp1MouseClicked(evt);
            }
        });
        jPanel2.add(hp1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 220, -1, -1));

        hp2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Hard/hpusheen2.png"))); // NOI18N
        hp2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hp2MouseClicked(evt);
            }
        });
        jPanel2.add(hp2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 250, -1, -1));

        hp3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Hard/hpusheen3.png"))); // NOI18N
        hp3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hp3MouseClicked(evt);
            }
        });
        jPanel2.add(hp3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 200, -1));

        hp4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Hard/hpusheen4.png"))); // NOI18N
        hp4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hp4MouseClicked(evt);
            }
        });
        jPanel2.add(hp4, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 180, -1, -1));

        hp5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Hard/hpusheen5.png"))); // NOI18N
        hp5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hp5MouseClicked(evt);
            }
        });
        jPanel2.add(hp5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 210, 20, 30));

        hp6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Hard/hpusheen6.png"))); // NOI18N
        hp6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hp6MouseClicked(evt);
            }
        });
        jPanel2.add(hp6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 150, -1, -1));

        hp7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Hard/hpusheen7.png"))); // NOI18N
        hp7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hp7MouseClicked(evt);
            }
        });
        jPanel2.add(hp7, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 250, -1, -1));

        hp8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Hard/hpusheen8.png"))); // NOI18N
        hp8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hp8MouseClicked(evt);
            }
        });
        jPanel2.add(hp8, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 240, 40, -1));

        hbg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/findpusheen/Levels/Hard/lvlhard.png"))); // NOI18N
        hbg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hbgMouseClicked(evt);
            }
        });
        jPanel2.add(hbg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(hback, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(301, 301, 301)
                        .addComponent(htitle_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(78, 78, 78)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(hcounter_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addComponent(hcounter, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(htime_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(htime, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(hback)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(htitle_lbl)))
                .addGap(52, 52, 52)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(hcounter_lbl)
                        .addGap(6, 6, 6)
                        .addComponent(hcounter)
                        .addGap(41, 41, 41)
                        .addComponent(htime_lbl)
                        .addGap(11, 11, 11)
                        .addComponent(htime)))
                .addContainerGap(81, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    void timerstart(){
        state = true;
        
        Thread t = new Thread(){
            @Override
            public void run(){                
                
                for(;;){
                    if(state == true){
                        try {
                            sleep(1);
                           
                            if(milliseconds>1000){
                                milliseconds = 00;
                                seconds++;
                            }
                            if(seconds>60){
                                seconds = 00;
                                minutes++;
                            }
                            
                            milliseconds++;
                            
                            
                            
                            if(seconds<10&&minutes<10){
                                htime.setText("0"+minutes+":0"+seconds);
                            }else if(seconds<10){
                                htime.setText(minutes+":0"+seconds);
                            }else if(minutes<10){
                                htime.setText("0"+minutes+":"+seconds);
                            }else{
                                htime.setText(minutes+":"+seconds);
                            }
                            
                        } catch (Exception e) {
                            
                        }
                    }
                    else{
                        break;
                    }
                }
            }
        };
        
        t.start();
        
    }
    
    void timerstop(){
        state = false;
    }
    
    void counter(){
        hcounter.setText(String.valueOf(epusheen));
        if(mouseclick ==1){
           timerstart();
       }
            
        if(epusheen == 0){
            timerstop();
            
            JOptionPane.showConfirmDialog(null,
                "Time: "+htime.getText(),
                "Congratulations you find all the pusheen!",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE);
            
            Choices ch = new Choices();
            this.hide();
            ch.show();
        }
    }
    
    private void hbackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hbackMouseClicked
        Choices ch = new Choices();
        this.hide();
        ch.show();
    }//GEN-LAST:event_hbackMouseClicked

    private void hp1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hp1MouseClicked
        hp1.setVisible(false);
        mouseclick++;
        epusheen--;
        counter();
    }//GEN-LAST:event_hp1MouseClicked

    private void hp2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hp2MouseClicked
        hp2.setVisible(false);
        mouseclick++;
        epusheen--;
        counter();
    }//GEN-LAST:event_hp2MouseClicked

    private void hp3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hp3MouseClicked
       hp3.setVisible(false);
       mouseclick++;
       epusheen--;
       counter();
    }//GEN-LAST:event_hp3MouseClicked

    private void hp4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hp4MouseClicked
       hp4.setVisible(false);
       mouseclick++;
       epusheen--;
       counter();
    }//GEN-LAST:event_hp4MouseClicked

    private void hp5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hp5MouseClicked
       hp5.setVisible(false);
       mouseclick++;
       epusheen--;
       counter(); 
    }//GEN-LAST:event_hp5MouseClicked

    private void hp6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hp6MouseClicked
       hp6.setVisible(false);
       mouseclick++;
       epusheen--;
       counter(); 
    }//GEN-LAST:event_hp6MouseClicked

    private void hp7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hp7MouseClicked
       hp7.setVisible(false);
       mouseclick++;
       epusheen--;
       counter();
    }//GEN-LAST:event_hp7MouseClicked

    private void hp8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hp8MouseClicked
       hp8.setVisible(false);
       mouseclick++;
       epusheen--;
       counter();
    }//GEN-LAST:event_hp8MouseClicked

    private void hbgMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hbgMouseClicked
       mouseclick++;
       counter();
    }//GEN-LAST:event_hbgMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Hard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Hard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Hard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Hard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Hard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel hback;
    private javax.swing.JLabel hbg;
    private javax.swing.JLabel hcounter;
    private javax.swing.JLabel hcounter_lbl;
    private javax.swing.JLabel hp1;
    private javax.swing.JLabel hp2;
    private javax.swing.JLabel hp3;
    private javax.swing.JLabel hp4;
    private javax.swing.JLabel hp5;
    private javax.swing.JLabel hp6;
    private javax.swing.JLabel hp7;
    private javax.swing.JLabel hp8;
    private javax.swing.JLabel htime;
    private javax.swing.JLabel htime_lbl;
    private javax.swing.JLabel htitle_lbl;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
